﻿namespace osm2mssql.Library.OpenStreetMapTypes
{
    public enum ElementType
    {
        Node = 1,
        Way = 2,
        Relation = 3
    }
}
