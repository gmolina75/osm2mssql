﻿namespace osm2mssql.Library.OpenStreetMapTypes
{
    public class Tag
    {
        public long Typ { get; set; }
        public string Value { get; set; }
    }
}
