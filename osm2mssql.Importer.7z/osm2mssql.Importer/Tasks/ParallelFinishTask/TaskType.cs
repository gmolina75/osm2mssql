﻿namespace osm2mssql.Importer.Tasks
{
    public enum TaskType
    {
        InitializeTask,
        ParallelTask,
        ParallelFinishTask,
        FinishTask
    }
}
