﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace osm2mssql.WebApp.Controllers.API
{
    public class GeoPoint
    {
        public double Latitude { get; set; }

        public double Longitude { get; set; }
    }
}
